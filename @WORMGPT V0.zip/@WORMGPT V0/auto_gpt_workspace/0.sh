#!/bin/bash

# This script generates an ASCII art of a cat

# ASCII art of a cat

echo ' /\_/\'
echo '( o o )'
echo ' >^_^<'
